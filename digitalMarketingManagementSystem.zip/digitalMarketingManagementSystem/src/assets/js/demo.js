var menu_btn =   document.querySelector("#menu-btn");
var sidebar = document.querySelector("#sidebar");
var container = document.querySelector(".my-container");
if(menu_btn){
menu_btn.addEventListener("click", () => {
  
 
});

function show(params) {
  
}

}
