export class HeaderEvent {
  type: 'ToggleNavBar' | 'AnyOtherType' | undefined;
  data: any;
}
